package com.bonytech.fuelalert

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.Ringtone
import android.media.RingtoneManager
import android.os.*
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.flow.MutableStateFlow

object Notifier {
    const val CH_SERVICE = "alarme_service"
    const val CH_INFO = "alertes_info"
    const val CH_SONORE = "alertes_sonore"
    private val COULEURS = intArrayOf(0xFFFFFFFF.toInt(), 0xFFFFD600.toInt(), 0xFFFF9100.toInt(), 0xFFFF1744.toInt())
    private const val ICON = android.R.drawable.ic_lock_idle_alarm

    fun channels(c: Context) {
        val nm = c.getSystemService(NotificationManager::class.java)
        val aa = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
        nm.createNotificationChannel(NotificationChannel(CH_SERVICE, "Alarme en cours", NotificationManager.IMPORTANCE_HIGH)
            .apply { setSound(null, null); enableVibration(false) })
        nm.createNotificationChannel(NotificationChannel(CH_INFO, "Alertes carburant", NotificationManager.IMPORTANCE_DEFAULT)
            .apply { setSound(null, null); enableVibration(false) })
        nm.createNotificationChannel(NotificationChannel(CH_SONORE, "Alertes sonores (secours)", NotificationManager.IMPORTANCE_HIGH)
            .apply {
                setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM), aa)
                enableVibration(true); vibrationPattern = longArrayOf(0, 800, 400, 800, 400, 800)
            })
    }

    fun texte(a: Alerte) =
        "${emojiNiveau(a.niveau)} ${labelNiveau(a.niveau)} — ${a.siteNom} : ${fmt(a.stock)} L restants, rupture estimée dans ${joursTxt(a.joursRestants)}"

    private fun ouvrir(c: Context): PendingIntent = PendingIntent.getActivity(
        c, 0, Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private fun arreter(c: Context): PendingIntent = PendingIntent.getService(
        c, 2, Intent(c, AlarmService::class.java).setAction(AlarmService.ACTION_STOP),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    fun serviceNotification(c: Context, lignes: List<String>, niveau: Int, canal: String = CH_SERVICE): Notification =
        NotificationCompat.Builder(c, canal)
            .setSmallIcon(ICON)
            .setContentTitle("BONYTECH FUEL ALERT")
            .setContentText(lignes.firstOrNull() ?: "")
            .setStyle(NotificationCompat.BigTextStyle().bigText(lignes.joinToString("\n")))
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setColor(COULEURS[niveau.coerceIn(0, 3)])
            .setOngoing(canal == CH_SERVICE)
            .setAutoCancel(canal != CH_SERVICE)
            .setContentIntent(ouvrir(c))
            .setFullScreenIntent(ouvrir(c), true)
            .addAction(0, "ARRÊTER LA SONNERIE", arreter(c))
            .build()

    fun sonore(c: Context, lignes: List<String>, niveau: Int = 3) {
        channels(c)
        c.getSystemService(NotificationManager::class.java)
            .notify(1, serviceNotification(c, lignes, niveau, CH_SONORE))
    }

    /** Notification par site + sonnerie/vibration persistante (service au premier plan). */
    fun alert(c: Context, ev: List<Alerte>) {
        channels(c)
        val nm = c.getSystemService(NotificationManager::class.java)
        ev.forEach { a ->
            nm.notify(
                2000 + a.siteId.toInt(),
                NotificationCompat.Builder(c, CH_INFO).setSmallIcon(ICON)
                    .setContentTitle("${labelNiveau(a.niveau)} — ${a.siteNom}")
                    .setContentText(texte(a))
                    .setStyle(NotificationCompat.BigTextStyle().bigText(texte(a)))
                    .setColor(COULEURS[a.niveau.coerceIn(0, 3)])
                    .setContentIntent(ouvrir(c)).setAutoCancel(true).build()
            )
        }
        val lignes = ev.map { texte(it) }
        val niveau = ev.maxOf { it.niveau }
        try {
            ContextCompat.startForegroundService(
                c, Intent(c, AlarmService::class.java)
                    .putStringArrayListExtra("lignes", ArrayList(lignes)).putExtra("niveau", niveau)
            )
        } catch (e: Exception) {
            sonore(c, lignes, niveau) // secours : notification sonore classique
        }
    }
}

class AlarmService : Service() {
    companion object {
        const val ACTION_STOP = "com.bonytech.fuelalert.STOP"
        const val NOTIF_ID = 42
        val sonne = MutableStateFlow(false)
    }

    private var ringtone: Ringtone? = null
    private val handler = Handler(Looper.getMainLooper())
    private val timeout = Runnable { arreterAlarme() }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        if (i?.action == ACTION_STOP) { arreterAlarme(); return START_NOT_STICKY }
        val lignes = i?.getStringArrayListExtra("lignes") ?: arrayListOf()
        val niveau = i?.getIntExtra("niveau", 1) ?: 1
        Notifier.channels(this)
        val n = Notifier.serviceNotification(this, lignes, niveau)
        try {
            if (Build.VERSION.SDK_INT >= 29)
                startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
            else startForeground(NOTIF_ID, n)
        } catch (e: Exception) {
            Notifier.sonore(this, lignes, niveau); stopSelf(); return START_NOT_STICKY
        }
        demarrerAlarme()
        handler.removeCallbacks(timeout)
        handler.postDelayed(timeout, 60_000) // s'arrête seule après 1 minute
        return START_NOT_STICKY
    }

    @Suppress("DEPRECATION")
    private fun demarrerAlarme() {
        arreterSon()
        sonne.value = true
        val aa = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
        try {
            val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
            ringtone = RingtoneManager.getRingtone(this, uri)?.apply {
                audioAttributes = aa
                if (Build.VERSION.SDK_INT >= 28) isLooping = true
                play()
            }
        } catch (_: Exception) { }
        try {
            val v = if (Build.VERSION.SDK_INT >= 31)
                getSystemService(VibratorManager::class.java).defaultVibrator
            else getSystemService(VIBRATOR_SERVICE) as Vibrator
            v.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 800, 400, 800, 400), 0), aa)
        } catch (_: Exception) { }
    }

    @Suppress("DEPRECATION")
    private fun arreterSon() {
        try { ringtone?.stop() } catch (_: Exception) { }
        ringtone = null
        try {
            val v = if (Build.VERSION.SDK_INT >= 31)
                getSystemService(VibratorManager::class.java).defaultVibrator
            else getSystemService(VIBRATOR_SERVICE) as Vibrator
            v.cancel()
        } catch (_: Exception) { }
    }

    private fun arreterAlarme() {
        handler.removeCallbacks(timeout)
        arreterSon()
        sonne.value = false
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() { handler.removeCallbacks(timeout); arreterSon(); sonne.value = false; super.onDestroy() }
}
