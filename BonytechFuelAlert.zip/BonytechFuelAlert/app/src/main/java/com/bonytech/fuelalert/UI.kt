package com.bonytech.fuelalert

import android.app.AlarmManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings as AS
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.LocalGasStation
import androidx.compose.material.icons.filled.Settings as SettingsIcon
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.launch
import java.time.LocalDate

val Jaune = Color(0xFFFFD600)
val Rouge = Color(0xFFFF1744)
val Orange = Color(0xFFFF9100)
val FondCarte = Color(0xFF141414)

fun couleur(n: Int) = when (n) { 1 -> Jaune; 2 -> Orange; 3 -> Rouge; else -> Color.White }

@Composable
fun AppTheme(content: @Composable () -> Unit) = MaterialTheme(
    colorScheme = darkColorScheme(
        primary = Jaune, onPrimary = Color.Black, secondary = Jaune, onSecondary = Color.Black,
        background = Color.Black, onBackground = Color.White,
        surface = Color(0xFF1A1A1A), onSurface = Color.White,
        surfaceVariant = Color(0xFF222222), onSurfaceVariant = Color(0xFFCCCCCC), error = Rouge
    ), content = content
)

// ------------------------------------------------------------------ composants
@Composable
fun Carte(modifier: Modifier = Modifier, bord: Color = Color(0xFF333333), onClick: (() -> Unit)? = null,
          content: @Composable ColumnScope.() -> Unit) {
    val m = if (onClick != null) modifier.clickable { onClick() } else modifier
    Card(modifier = m, colors = CardDefaults.cardColors(containerColor = FondCarte), border = BorderStroke(1.dp, bord)) {
        Column(Modifier.padding(14.dp), content = content)
    }
}

@Composable
fun Kpi(titre: String, valeur: String, mod: Modifier, c: Color = Color.White) =
    Carte(mod, bord = c.copy(alpha = 0.5f)) {
        Text(valeur, color = c, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text(titre, color = Color.LightGray, fontSize = 12.sp)
    }

@Composable
fun Badge(n: Int) = Surface(color = couleur(n), shape = RoundedCornerShape(50)) {
    Text(labelNiveau(n), color = if (n == 3) Color.White else Color.Black, fontSize = 11.sp,
        fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp))
}

@Composable
fun BarChart(vals: List<Double>, labels: List<String>, color: Color = Jaune) {
    val max = (vals.maxOrNull() ?: 0.0).coerceAtLeast(1.0)
    Column {
        Canvas(Modifier.fillMaxWidth().height(120.dp)) {
            val n = vals.size
            if (n == 0) return@Canvas
            val w = size.width / n
            vals.forEachIndexed { i, v ->
                val h = (v / max * size.height).toFloat()
                drawRect(color, topLeft = Offset(i * w + w * 0.15f, size.height - h), size = Size(w * 0.7f, h))
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(labels.firstOrNull() ?: "", color = Color.Gray, fontSize = 11.sp)
            Text("max ${fmt(max)} L/j", color = Color.Gray, fontSize = 11.sp)
            Text(labels.lastOrNull() ?: "", color = Color.Gray, fontSize = 11.sp)
        }
    }
}

@Composable
fun BandeauAlarme() {
    val ctx = LocalContext.current
    Surface(color = Rouge) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("🔔 ALARME EN COURS", color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Button(
                onClick = { ctx.startService(Intent(ctx, AlarmService::class.java).setAction(AlarmService.ACTION_STOP)) },
                colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black)
            ) { Text("ARRÊTER") }
        }
    }
}

// ------------------------------------------------------------------ application
@Composable
fun App(vm: MainVM) {
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var detailId by rememberSaveable { mutableStateOf<Long?>(null) }
    val stats by vm.stats.collectAsStateWithLifecycle()
    val ops by vm.ops.collectAsStateWithLifecycle()
    val alertes by vm.alertes.collectAsStateWithLifecycle()
    val sonne by AlarmService.sonne.collectAsStateWithLifecycle()
    val msg by vm.message.collectAsStateWithLifecycle()
    val snack = remember { SnackbarHostState() }
    LaunchedEffect(msg) { msg?.let { snack.showSnackbar(it); vm.message.value = null } }

    val detail = detailId?.let { id -> stats.firstOrNull { it.site.id == id } }
    BackHandler(detail != null) { detailId = null }

    val items = listOf(
        "Accueil" to Icons.Filled.Dashboard, "Sites" to Icons.Filled.LocalGasStation,
        "Historique" to Icons.Filled.History, "Rapports" to Icons.Filled.Description,
        "Réglages" to Icons.Filled.SettingsIcon
    )
    Scaffold(
        containerColor = Color.Black,
        snackbarHost = { SnackbarHost(snack) },
        bottomBar = {
            NavigationBar(containerColor = Color(0xFF111111)) {
                items.forEachIndexed { i, (label, icon) ->
                    NavigationBarItem(
                        selected = tab == i && detail == null,
                        onClick = { tab = i; detailId = null },
                        icon = { Icon(icon, contentDescription = label) },
                        label = { Text(label, fontSize = 10.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.Black, indicatorColor = Jaune, selectedTextColor = Jaune,
                            unselectedIconColor = Color.White, unselectedTextColor = Color.White
                        )
                    )
                }
            }
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            if (sonne) BandeauAlarme()
            Box(Modifier.weight(1f)) {
                if (detail != null) SiteDetail(vm, detail, ops, { detailId = null })
                else when (tab) {
                    0 -> Accueil(stats, ops) { detailId = it }
                    1 -> SitesScreen(vm, stats) { detailId = it }
                    2 -> Historique(stats, ops, alertes)
                    3 -> Rapports()
                    else -> Reglages(vm)
                }
            }
        }
    }
}

// ------------------------------------------------------------------ accueil
@Composable
fun Accueil(stats: List<Stats>, ops: List<Operation>, onOpen: (Long) -> Unit) {
    val prochain = stats.filter { it.jours != null }.minByOrNull { it.jours!! }
    val (vals, labels) = conso14(ops, null)
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Column {
                Text("BONYTECH FUEL ALERT", color = Jaune, fontWeight = FontWeight.Bold, fontSize = 22.sp)
                Text("Surveillance du carburant — fonctionne hors connexion", color = Color.LightGray, fontSize = 12.sp)
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Kpi("Sites enregistrés", "${stats.size}", Modifier.weight(1f))
                Kpi("Stock total", "${fmt(stats.sumOf { it.stock })} L", Modifier.weight(1f), Jaune)
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Kpi("Normaux", "${stats.count { it.niveau == 0 }}", Modifier.weight(1f))
                Kpi("En alerte", "${stats.count { it.niveau in 1..2 }}", Modifier.weight(1f), Orange)
                Kpi("Critiques", "${stats.count { it.niveau == 3 }}", Modifier.weight(1f), Rouge)
            }
        }
        item {
            Carte(Modifier.fillMaxWidth(), bord = prochain?.let { couleur(it.niveau) } ?: Color(0xFF333333),
                onClick = prochain?.let { p -> { onOpen(p.site.id) } }) {
                Text("Prochain site en rupture", color = Color.LightGray, fontSize = 12.sp)
                if (prochain == null) Text("Aucun site avec consommation définie", color = Color.White)
                else {
                    Text(prochain.site.nom, color = Jaune, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text("${fmt(prochain.stock)} L • ${joursTxt(prochain.jours)} • rupture le ${fd(prochain.dateRupture!!)}", color = Color.White)
                }
            }
        }
        item {
            Carte(Modifier.fillMaxWidth()) {
                Text("Consommation — 14 derniers jours", color = Color.LightGray, fontSize = 12.sp)
                Spacer(Modifier.height(8.dp))
                BarChart(vals, labels)
            }
        }
    }
}

// ------------------------------------------------------------------ sites
@Composable
fun SiteCard(s: Stats, onClick: () -> Unit) {
    val c = if (s.niveau == 0) Jaune else couleur(s.niveau)
    Carte(Modifier.fillMaxWidth(), bord = if (s.niveau == 0) Color(0xFF333333) else c, onClick = onClick) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(s.site.nom, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text(s.site.localisation, color = Color.Gray, fontSize = 12.sp)
            }
            Badge(s.niveau)
        }
        Spacer(Modifier.height(8.dp))
        Text("${fmt(s.stock)} L", color = c, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        val max = (s.site.stockInitial + s.ravit).coerceAtLeast(1.0)
        LinearProgressIndicator(
            progress = { (s.stock / max).toFloat().coerceIn(0f, 1f) },
            modifier = Modifier.fillMaxWidth().height(8.dp), color = c, trackColor = Color(0xFF333333)
        )
        Spacer(Modifier.height(6.dp))
        Text("Autonomie : ${joursTxt(s.jours)}  •  Rupture : ${s.dateRupture?.let { fd(it) } ?: "—"}", color = Color.LightGray, fontSize = 12.sp)
    }
}

@Composable
fun SitesScreen(vm: MainVM, stats: List<Stats>, onOpen: (Long) -> Unit) {
    var ajout by remember { mutableStateOf(false) }
    Box(Modifier.fillMaxSize()) {
        if (stats.isEmpty()) Text("Aucun site. Appuyez sur + pour en ajouter un.", color = Color.LightGray,
            modifier = Modifier.align(Alignment.Center).padding(24.dp))
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp, 16.dp, 16.dp, 90.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(stats, key = { it.site.id }) { s -> SiteCard(s) { onOpen(s.site.id) } }
        }
        FloatingActionButton(onClick = { ajout = true }, containerColor = Jaune, contentColor = Color.Black,
            modifier = Modifier.align(Alignment.BottomEnd).padding(20.dp)) { Icon(Icons.Filled.Add, "Ajouter un site") }
    }
    if (ajout) SiteDialog(null, { n, l, st, c -> vm.ajouterSite(n, l, st, c); ajout = false }, { ajout = false })
}

@Composable
fun SiteDetail(vm: MainVM, s: Stats, ops: List<Operation>, onBack: () -> Unit) {
    var dlg by remember { mutableIntStateOf(0) }
    val (vals, labels) = conso14(ops, s.site.id)
    val c = if (s.niveau == 0) Jaune else couleur(s.niveau)
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Retour", tint = Color.White) }
                Column(Modifier.weight(1f)) {
                    Text(s.site.nom, color = Jaune, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text(s.site.localisation, color = Color.Gray, fontSize = 12.sp)
                }
                Badge(s.niveau)
            }
        }
        item {
            Carte(Modifier.fillMaxWidth(), bord = c) {
                Text("Stock actuel : ${fmt(s.stock)} L", color = c, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Text("Autonomie estimée : ${joursTxt(s.jours)}", color = Color.White)
                Text("Date prévisionnelle de rupture : ${s.dateRupture?.let { fd(it) } ?: "—"}", color = Color.White)
                Text("Date prévisionnelle d'atteinte des 300 L : ${s.date300?.let { fd(it) } ?: "—"}", color = Color.White)
                Spacer(Modifier.height(6.dp))
                Text("Stock initial ${fmt(s.site.stockInitial)} L • Ravitaillements ${fmt(s.ravit)} L • Consommé ${fmt(s.conso)} L",
                    color = Color.Gray, fontSize = 12.sp)
                Text("Consommation journalière estimée : ${fmt(s.site.consoJournaliere)} L", color = Color.Gray, fontSize = 12.sp)
            }
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button({ dlg = 1 }, Modifier.weight(1f)) { Text("Ravitailler") }
                    Button({ dlg = 2 }, Modifier.weight(1f)) { Text("Conso réelle") }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton({ dlg = 3 }, Modifier.weight(1f)) { Text("Modifier", color = Color.White) }
                    OutlinedButton({ dlg = 4 }, Modifier.weight(1f), border = BorderStroke(1.dp, Rouge)) { Text("Supprimer", color = Rouge) }
                }
            }
        }
        item {
            Carte(Modifier.fillMaxWidth()) {
                Text("Consommation — 14 derniers jours", color = Color.LightGray, fontSize = 12.sp)
                Spacer(Modifier.height(8.dp))
                BarChart(vals, labels)
            }
        }
        item { Text("Historique du site", color = Jaune, fontWeight = FontWeight.Bold) }
        val mine = ops.filter { it.siteId == s.site.id }
        items(mine, key = { it.id }) { OpRow(it, null) }
    }
    when (dlg) {
        1 -> SaisieDialog("Ravitaillement — ${s.site.nom}", false, true, true,
            { l, _, n -> vm.ravitailler(s.site.id, l, n); dlg = 0 }, { dlg = 0 })
        2 -> SaisieDialog("Consommation réelle — ${s.site.nom}", true, false, false,
            { l, j, _ -> vm.consoReelle(s.site.id, l, LocalDate.now().minusDays(j.toLong())); dlg = 0 }, { dlg = 0 })
        3 -> SiteDialog(s.site, { n, l, st, co -> vm.modifierSite(s.site, n, l, st, co); dlg = 0 }, { dlg = 0 })
        4 -> AlertDialog(
            onDismissRequest = { dlg = 0 },
            title = { Text("Supprimer ${s.site.nom} ?") },
            text = { Text("Le site et tout son historique seront supprimés définitivement.") },
            confirmButton = { TextButton({ vm.supprimerSite(s.site); dlg = 0; onBack() }) { Text("Supprimer", color = Rouge) } },
            dismissButton = { TextButton({ dlg = 0 }) { Text("Annuler") } }
        )
    }
}

@Composable
fun OpRow(o: Operation, site: String?) {
    val (txt, col) = when (o.type) {
        Type.RAVITAILLEMENT -> "⛽ Ravitaillement +${fmt(o.litres)} L" to Jaune
        Type.CONSOMMATION -> "🔻 Consommation ${if (o.reelle) "réelle" else "estimée"} −${fmt(o.litres)} L" to Color.White
        else -> "✏️ Changement de stock" to Color.LightGray
    }
    Carte(Modifier.fillMaxWidth()) {
        Text(txt, color = col, fontWeight = FontWeight.Bold)
        if (site != null) Text(site, color = Color.White, fontSize = 13.sp)
        val detail = o.jour?.let { "Jour : ${fd(LocalDate.parse(it))} • " } ?: ""
        Text(detail + dt(o.date) + if (o.note.isNotBlank()) " • ${o.note}" else "", color = Color.Gray, fontSize = 11.sp)
    }
}

// ------------------------------------------------------------------ dialogues
@Composable
fun SiteDialog(site: Site?, onSave: (String, String, Double, Double) -> Unit, onCancel: () -> Unit) {
    var nom by remember { mutableStateOf(site?.nom ?: "") }
    var loc by remember { mutableStateOf(site?.localisation ?: "") }
    var stock by remember { mutableStateOf(site?.let { fmt(it.stockInitial) } ?: "") }
    var conso by remember { mutableStateOf(site?.let { fmt(it.consoJournaliere) } ?: "") }
    val num = KeyboardOptions(keyboardType = KeyboardType.Decimal)
    AlertDialog(
        onDismissRequest = onCancel,
        title = { Text(if (site == null) "Ajouter un site" else "Modifier le site") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(nom, { nom = it }, label = { Text("Nom du site") }, singleLine = true)
                OutlinedTextField(loc, { loc = it }, label = { Text("Localisation") }, singleLine = true)
                OutlinedTextField(stock, { stock = it }, label = { Text("Stock initial (L)") }, singleLine = true, keyboardOptions = num)
                OutlinedTextField(conso, { conso = it }, label = { Text("Consommation journalière (L)") }, singleLine = true, keyboardOptions = num)
            }
        },
        confirmButton = {
            TextButton({
                val st = stock.replace(',', '.').toDoubleOrNull()
                val co = conso.replace(',', '.').toDoubleOrNull()
                if (nom.isNotBlank() && st != null && st >= 0 && co != null && co >= 0) onSave(nom, loc, st, co)
            }) { Text("Enregistrer") }
        },
        dismissButton = { TextButton(onCancel) { Text("Annuler") } }
    )
}

@Composable
fun SaisieDialog(titre: String, avecJour: Boolean, avecNote: Boolean, strict: Boolean,
                 onOk: (Double, Int, String) -> Unit, onCancel: () -> Unit) {
    var l by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var jour by remember { mutableIntStateOf(0) }
    AlertDialog(
        onDismissRequest = onCancel,
        title = { Text(titre) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(l, { l = it }, label = { Text("Litres") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                if (avecJour) listOf("Aujourd'hui", "Hier", "Avant-hier").forEachIndexed { i, t ->
                    FilterChip(selected = jour == i, onClick = { jour = i }, label = { Text(t) })
                }
                if (avecNote) OutlinedTextField(note, { note = it }, label = { Text("Note (facultatif)") }, singleLine = true)
            }
        },
        confirmButton = {
            TextButton({
                val v = l.replace(',', '.').toDoubleOrNull()
                if (v != null && (if (strict) v > 0 else v >= 0)) onOk(v, jour, note)
            }) { Text("Enregistrer") }
        },
        dismissButton = { TextButton(onCancel) { Text("Annuler") } }
    )
}

// ------------------------------------------------------------------ historique
@Composable
fun Historique(stats: List<Stats>, ops: List<Operation>, alertes: List<Alerte>) {
    var mode by rememberSaveable { mutableIntStateOf(0) }
    val noms = stats.associate { it.site.id to it.site.nom }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.padding(16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(mode == 0, { mode = 0 }, { Text("Opérations") })
            FilterChip(mode == 1, { mode = 1 }, { Text("Alertes") })
        }
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp, 0.dp, 16.dp, 16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (mode == 0) items(ops, key = { it.id }) { OpRow(it, noms[it.siteId] ?: "Site supprimé") }
            else items(alertes, key = { it.id }) { a ->
                Carte(Modifier.fillMaxWidth(), bord = couleur(a.niveau)) {
                    Text("${emojiNiveau(a.niveau)} ${labelNiveau(a.niveau)} — ${a.siteNom}", color = couleur(a.niveau), fontWeight = FontWeight.Bold)
                    Text("${fmt(a.stock)} L restants • rupture dans ${joursTxt(a.joursRestants)}", color = Color.White, fontSize = 13.sp)
                    Text(dt(a.date), color = Color.Gray, fontSize = 11.sp)
                }
            }
        }
    }
}

// ------------------------------------------------------------------ rapports
@Composable
fun Rapports() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Column {
                Text("Rapports PDF", color = Jaune, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("Le PDF est généré puis proposé au partage (WhatsApp, e-mail, etc.).", color = Color.LightGray, fontSize = 12.sp)
            }
        }
        items(RapportType.values().toList()) { t ->
            Button(
                onClick = {
                    scope.launch {
                        busy = true
                        try { Reports.partager(ctx, Reports.generer(ctx, t), "application/pdf") } catch (_: Exception) { }
                        busy = false
                    }
                },
                enabled = !busy, modifier = Modifier.fillMaxWidth().height(56.dp)
            ) { Text(t.label, fontSize = 16.sp) }
        }
    }
}

// ------------------------------------------------------------------ réglages
@Composable
fun Statut(texte: String, ok: Boolean, bouton: String, onClick: () -> Unit) =
    Carte(Modifier.fillMaxWidth(), bord = if (ok) Color(0xFF333333) else Orange) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text((if (ok) "✔ " else "✖ ") + texte, color = Color.White, modifier = Modifier.weight(1f))
            if (!ok) TextButton(onClick) { Text(bouton, color = Jaune) }
        }
    }

@Composable
fun Reglages(vm: MainVM) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val tick by vm.tick.collectAsStateWithLifecycle()
    val notifOk = remember(tick) { NotificationManagerCompat.from(ctx).areNotificationsEnabled() }
    val exactOk = remember(tick) { Build.VERSION.SDK_INT < 31 || ctx.getSystemService(AlarmManager::class.java).canScheduleExactAlarms() }
    val battOk = remember(tick) { ctx.getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(ctx.packageName) }
    val restaurer = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> uri?.let { vm.restaurer(it) } }

    fun ouvrir(i: Intent) { try { ctx.startActivity(i) } catch (_: Exception) { } }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("Réglages & fiabilité des alarmes", color = Jaune, fontSize = 22.sp, fontWeight = FontWeight.Bold) }
        item {
            Statut("Notifications autorisées", notifOk, "Régler") {
                ouvrir(Intent(AS.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(AS.EXTRA_APP_PACKAGE, ctx.packageName))
            }
        }
        item {
            Statut("Alarmes précises autorisées", exactOk, "Régler") {
                if (Build.VERSION.SDK_INT >= 31)
                    ouvrir(Intent(AS.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:${ctx.packageName}")))
            }
        }
        item { Statut("Économie de batterie désactivée pour l'app", battOk, "Régler") { ouvrir(Intent(AS.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) } }
        item {
            Text("TECNO : dans Paramètres > Gestionnaire de téléphone (ou Batterie) > autorisez le démarrage automatique " +
                "et « sans restriction » pour BONYTECH FUEL ALERT, et verrouillez l'app dans les applications récentes.",
                color = Color.LightGray, fontSize = 12.sp)
        }
        item {
            Button(
                onClick = {
                    scope.launch {
                        Notifier.alert(ctx, listOf(Alerte(siteId = 0, siteNom = "TEST", niveau = 3, stock = 40.0, joursRestants = 0.4, date = System.currentTimeMillis())))
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = Rouge, contentColor = Color.White),
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) { Text("Tester la sonnerie et la vibration") }
        }
        item { Text("Sauvegarde des données", color = Jaune, fontWeight = FontWeight.Bold) }
        item {
            Text("Les données sont enregistrées automatiquement sur le téléphone. Exportez un fichier de sauvegarde pour le conserver ailleurs.",
                color = Color.LightGray, fontSize = 12.sp)
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button({ scope.launch { try { Reports.partager(ctx, Reports.exporter(ctx), "application/json") } catch (_: Exception) { } } },
                    Modifier.weight(1f)) { Text("Exporter") }
                OutlinedButton({ restaurer.launch(arrayOf("*/*")) }, Modifier.weight(1f)) { Text("Restaurer", color = Color.White) }
            }
        }
    }
}
