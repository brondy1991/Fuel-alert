package com.bonytech.fuelalert

import android.content.Context
import android.content.Intent
import android.graphics.*
import android.graphics.pdf.PdfDocument
import android.net.Uri
import androidx.core.content.FileProvider
import androidx.room.withTransaction
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.time.LocalDate

enum class RapportType(val label: String) {
    JOURNALIER("Rapport journalier"),
    HEBDO("Rapport hebdomadaire"),
    MENSUEL("Rapport mensuel"),
    SITUATION("Situation générale des stocks"),
    ALERTES("Historique des alertes"),
    CONSO("Consommation par site (30 jours)")
}

class PdfWriter {
    private val doc = PdfDocument()
    private var page: PdfDocument.Page? = null
    private var c: Canvas? = null
    private var y = 0f
    private var n = 0
    private val W = 595
    private val H = 842
    private val M = 40f
    private val p = Paint().apply { isAntiAlias = true; textSize = 10f; color = Color.BLACK }
    private val pb = Paint(p).apply { typeface = Typeface.DEFAULT_BOLD }
    private val ph = Paint(pb).apply { textSize = 18f }
    private val pt = Paint(pb).apply { textSize = 14f }
    private val jaune = Paint().apply { color = Color.rgb(255, 214, 0) }

    init { nouvellePage() }

    private fun nouvellePage() {
        page?.let { doc.finishPage(it) }
        n++
        val pg = doc.startPage(PdfDocument.PageInfo.Builder(W, H, n).create())
        page = pg; c = pg.canvas
        c!!.drawRect(0f, 0f, W.toFloat(), 46f, jaune)
        c!!.drawText("BONYTECH FUEL ALERT", M, 30f, ph)
        y = 72f
    }

    private fun verifie(h: Float = 16f) { if (y + h > H - M) nouvellePage() }
    fun titre(t: String) { verifie(30f); c!!.drawText(t, M, y, pt); y += 22f }
    fun ligne(t: String, gras: Boolean = false) { verifie(); c!!.drawText(t, M, y, if (gras) pb else p); y += 15f }
    fun espace(h: Float = 8f) { y += h }

    fun rangee(cols: List<String>, xs: List<Float>, gras: Boolean = false) {
        verifie()
        cols.forEachIndexed { i, s ->
            val x = xs[i]
            val nx = if (i + 1 < xs.size) xs[i + 1] else (W - M)
            val max = ((nx - x) / 5.2f).toInt().coerceAtLeast(3)
            val t = if (s.length > max) s.take(max - 1) + "…" else s
            c!!.drawText(t, x, y, if (gras) pb else p)
        }
        y += 15f
        if (gras) c!!.drawLine(M, y - 11f, W - M, y - 11f, p)
    }

    fun terminer(f: File) {
        page?.let { doc.finishPage(it) }
        f.outputStream().use { doc.writeTo(it) }
        doc.close()
    }
}

object Reports {
    private fun dossier(ctx: Context) = File(ctx.cacheDir, "reports").apply { mkdirs() }
    private fun dans(x: LocalDate, a: LocalDate, b: LocalDate) = !x.isBefore(a) && !x.isAfter(b)
    private fun typeTxt(o: Operation) = when (o.type) {
        Type.RAVITAILLEMENT -> "Ravitaillement"
        Type.CONSOMMATION -> if (o.reelle) "Conso. réelle" else "Conso. estimée"
        else -> "Changement"
    }

    suspend fun generer(ctx: Context, t: RapportType): File = withContext(Dispatchers.IO) {
        val dao = AppDb.get(ctx).dao()
        val sites = dao.sites(); val ops = dao.allOps(); val al = dao.alertes()
        val today = LocalDate.now()
        val stats = sites.map { calc(it, ops, today) }
        val noms = sites.associate { it.id to it.nom }
        val (a, b) = when (t) {
            RapportType.JOURNALIER -> today to today
            RapportType.HEBDO -> today.minusDays(6) to today
            RapportType.MENSUEL -> today.withDayOfMonth(1) to today
            RapportType.CONSO -> today.minusDays(29) to today
            else -> today to today
        }
        val w = PdfWriter()
        w.titre(t.label)
        w.ligne("Généré le ${dt(System.currentTimeMillis())}")
        w.ligne("Stock total : ${fmt(stats.sumOf { it.stock })} L  •  Sites : ${stats.size}")
        w.espace()

        when (t) {
            RapportType.JOURNALIER, RapportType.HEBDO, RapportType.MENSUEL -> {
                w.ligne("Période : ${fd(a)} au ${fd(b)}", true); w.espace()
                val xs = listOf(40f, 170f, 250f, 330f, 410f, 490f)
                w.rangee(listOf("Site", "Ravit. (L)", "Conso (L)", "Stock (L)", "Autonomie", "État"), xs, true)
                var tr = 0.0; var tc = 0.0
                stats.forEach { s ->
                    val r = ops.filter { it.siteId == s.site.id && it.type == Type.RAVITAILLEMENT && dans(jourDe(it.date), a, b) }.sumOf { it.litres }
                    val c = ops.filter { it.siteId == s.site.id && it.type == Type.CONSOMMATION && it.jour != null && dans(LocalDate.parse(it.jour), a, b) }.sumOf { it.litres }
                    tr += r; tc += c
                    w.rangee(listOf(s.site.nom, fmt(r), fmt(c), fmt(s.stock), joursTxt(s.jours), labelNiveau(s.niveau)), xs)
                }
                w.rangee(listOf("TOTAL", fmt(tr), fmt(tc), fmt(stats.sumOf { it.stock }), "", ""), xs, true)
                w.espace(12f)
                w.ligne("Opérations de la période", true)
                val xo = listOf(40f, 130f, 260f, 370f)
                w.rangee(listOf("Date", "Site", "Type", "Litres"), xo, true)
                ops.filter { dans(jourDe(it.date), a, b) && it.type != Type.CHANGEMENT }.take(150).forEach {
                    w.rangee(listOf(dt(it.date), noms[it.siteId] ?: "?", typeTxt(it), fmt(it.litres)), xo)
                }
                w.espace(12f)
                w.ligne("Alertes de la période", true)
                val pa = al.filter { dans(jourDe(it.date), a, b) }
                if (pa.isEmpty()) w.ligne("Aucune alerte.")
                pa.forEach { w.ligne("${dt(it.date)} — ${it.siteNom} : ${labelNiveau(it.niveau)} (${fmt(it.stock)} L)") }
            }
            RapportType.SITUATION -> {
                val xs = listOf(40f, 125f, 215f, 270f, 335f, 420f, 490f)
                w.rangee(listOf("Site", "Localisation", "Stock (L)", "Conso/j", "Autonomie", "Rupture", "État"), xs, true)
                stats.sortedBy { it.jours ?: Double.MAX_VALUE }.forEach { s ->
                    w.rangee(listOf(s.site.nom, s.site.localisation, fmt(s.stock), fmt(s.site.consoJournaliere),
                        joursTxt(s.jours), s.dateRupture?.let { fd(it) } ?: "—", labelNiveau(s.niveau)), xs)
                }
                w.espace()
                w.ligne("Normaux : ${stats.count { it.niveau == 0 }}  •  En alerte : ${stats.count { it.niveau in 1..2 }}  •  Critiques : ${stats.count { it.niveau == 3 }}", true)
            }
            RapportType.ALERTES -> {
                val xs = listOf(40f, 130f, 260f, 400f, 470f)
                w.rangee(listOf("Date", "Site", "Niveau", "Stock (L)", "Jours"), xs, true)
                if (al.isEmpty()) w.ligne("Aucune alerte enregistrée.")
                al.take(300).forEach { w.rangee(listOf(dt(it.date), it.siteNom, labelNiveau(it.niveau), fmt(it.stock), joursTxt(it.joursRestants)), xs) }
            }
            RapportType.CONSO -> {
                w.ligne("Période : ${fd(a)} au ${fd(b)}", true); w.espace()
                val xs = listOf(40f, 190f, 290f, 380f, 470f)
                w.rangee(listOf("Site", "Total (L)", "Moy./jour", "Jours réels", "Estimé/j"), xs, true)
                stats.forEach { s ->
                    val cs = ops.filter { it.siteId == s.site.id && it.type == Type.CONSOMMATION && it.jour != null && dans(LocalDate.parse(it.jour), a, b) }
                    val tot = cs.sumOf { it.litres }
                    w.rangee(listOf(s.site.nom, fmt(tot), fmt(tot / 30.0), cs.count { it.reelle }.toString(), fmt(s.site.consoJournaliere)), xs)
                }
            }
        }
        val f = File(dossier(ctx), "${t.name.lowercase()}_$today.pdf")
        w.terminer(f)
        f
    }

    fun partager(ctx: Context, f: File, mime: String) {
        val uri: Uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", f)
        val i = Intent(Intent.ACTION_SEND).apply {
            type = mime
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(Intent.createChooser(i, "Partager").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    // ---------- Sauvegarde / restauration (JSON) ----------
    suspend fun exporter(ctx: Context): File = withContext(Dispatchers.IO) {
        val dao = AppDb.get(ctx).dao()
        val root = JSONObject().put("version", 1)
        root.put("sites", JSONArray().also { arr ->
            dao.sites().forEach { s ->
                arr.put(JSONObject().put("id", s.id).put("nom", s.nom).put("loc", s.localisation)
                    .put("stock", s.stockInitial).put("conso", s.consoJournaliere).put("cree", s.creeLe)
                    .put("jour", s.prochainJour).put("niv", s.niveauAlerte))
            }
        })
        root.put("ops", JSONArray().also { arr ->
            dao.allOps().forEach { o ->
                arr.put(JSONObject().put("id", o.id).put("siteId", o.siteId).put("type", o.type).put("litres", o.litres)
                    .put("date", o.date).put("jour", o.jour ?: JSONObject.NULL).put("reelle", o.reelle).put("note", o.note))
            }
        })
        root.put("alertes", JSONArray().also { arr ->
            dao.alertes().forEach { a ->
                arr.put(JSONObject().put("id", a.id).put("siteId", a.siteId).put("nom", a.siteNom).put("niveau", a.niveau)
                    .put("stock", a.stock).put("jours", a.joursRestants ?: JSONObject.NULL).put("date", a.date))
            }
        })
        val f = File(dossier(ctx), "sauvegarde_fuel_${LocalDate.now()}.json")
        f.writeText(root.toString())
        f
    }

    suspend fun importer(ctx: Context, uri: Uri) = withContext(Dispatchers.IO) {
        val txt = ctx.contentResolver.openInputStream(uri)!!.use { it.readBytes().toString(Charsets.UTF_8) }
        val root = JSONObject(txt)
        fun arr(k: String): List<JSONObject> = root.getJSONArray(k).let { a -> (0 until a.length()).map { a.getJSONObject(it) } }
        val sites = arr("sites").map {
            Site(it.getLong("id"), it.getString("nom"), it.getString("loc"), it.getDouble("stock"), it.getDouble("conso"),
                it.getLong("cree"), it.getString("jour"), it.getInt("niv"))
        }
        val ops = arr("ops").map {
            Operation(it.getLong("id"), it.getLong("siteId"), it.getString("type"), it.getDouble("litres"), it.getLong("date"),
                if (it.isNull("jour")) null else it.getString("jour"), it.getBoolean("reelle"), it.getString("note"))
        }
        val al = arr("alertes").map {
            Alerte(it.getLong("id"), it.getLong("siteId"), it.getString("nom"), it.getInt("niveau"), it.getDouble("stock"),
                if (it.isNull("jours")) null else it.getDouble("jours"), it.getLong("date"))
        }
        val db = AppDb.get(ctx)
        db.withTransaction {
            val dao = db.dao()
            dao.clearAlertes(); dao.clearSites()
            dao.insertSites(sites); dao.insertOps(ops); dao.insertAlertes(al)
        }
    }
}
