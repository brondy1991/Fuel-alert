package com.bonytech.fuelalert

import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.roundToLong

val FR: Locale = Locale.FRANCE
private val DF = DateTimeFormatter.ofPattern("dd/MM/yyyy", FR)
private val DTF = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm", FR)

fun fd(d: LocalDate): String = d.format(DF)
fun dt(ms: Long): String = Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault()).format(DTF)
fun jourDe(ms: Long): LocalDate = Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault()).toLocalDate()
fun fmt(v: Double): String =
    if (abs(v - v.roundToLong()) < 0.05) v.roundToLong().toString() else String.format(FR, "%.1f", v)

fun joursTxt(j: Double?): String {
    if (j == null) return "—"
    if (j < 1.0) return "moins d'1 jour"
    val t = floor(j * 10) / 10
    return fmt(t) + if (t < 2) " jour" else " jours"
}

const val SEUIL_FAIBLE = 300.0
const val SEUIL_URGENT = 150.0
const val SEUIL_CRITIQUE = 50.0

fun niveauPour(stock: Double): Int = when {
    stock <= SEUIL_CRITIQUE -> 3
    stock <= SEUIL_URGENT -> 2
    stock <= SEUIL_FAIBLE -> 1
    else -> 0
}

fun labelNiveau(n: Int) = listOf("NORMAL", "STOCK FAIBLE", "STOCK URGENT", "STOCK CRITIQUE")[n.coerceIn(0, 3)]
fun emojiNiveau(n: Int) = listOf("⚪", "🟡", "🟠", "🔴")[n.coerceIn(0, 3)]

data class Stats(
    val site: Site,
    val stock: Double,
    val ravit: Double,
    val conso: Double,
    val niveau: Int,
    val jours: Double?,
    val dateRupture: LocalDate?,
    val date300: LocalDate?
)

/** Stock restant = stock initial + total des ravitaillements - total des consommations (jamais négatif). */
fun calc(site: Site, ops: List<Operation>, today: LocalDate = LocalDate.now()): Stats {
    val mine = ops.filter { it.siteId == site.id }
    val r = mine.filter { it.type == Type.RAVITAILLEMENT }.sumOf { it.litres }
    val c = mine.filter { it.type == Type.CONSOMMATION }.sumOf { it.litres }
    val stock = (site.stockInitial + r - c).coerceAtLeast(0.0)
    val d = site.consoJournaliere
    val jours = if (d > 0) stock / d else null
    val rupture = if (d > 0) today.plusDays(ceil(stock / d).toLong()) else null
    val d300 = if (d > 0) {
        if (stock <= SEUIL_FAIBLE) today else today.plusDays(ceil((stock - SEUIL_FAIBLE) / d).toLong())
    } else null
    return Stats(site, stock, r, c, niveauPour(stock), jours, rupture, d300)
}

/** Consommation des 14 derniers jours (un site, ou tous si siteId == null). */
fun conso14(ops: List<Operation>, siteId: Long?): Pair<List<Double>, List<String>> {
    val today = LocalDate.now()
    val vals = ArrayList<Double>(); val labels = ArrayList<String>()
    for (i in 13 downTo 0) {
        val day = today.minusDays(i.toLong())
        vals += ops.filter { it.type == Type.CONSOMMATION && it.jour == day.toString() && (siteId == null || it.siteId == siteId) }
            .sumOf { it.litres }
        labels += String.format(FR, "%02d/%02d", day.dayOfMonth, day.monthValue)
    }
    return vals to labels
}
