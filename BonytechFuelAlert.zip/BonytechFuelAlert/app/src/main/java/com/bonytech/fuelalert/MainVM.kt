package com.bonytech.fuelalert

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.withTransaction
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.LocalDate

class MainVM(private val app: Application) : AndroidViewModel(app) {
    private val db = AppDb.get(app)
    private val dao = db.dao()

    val sites = dao.sitesFlow().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val ops = dao.opsFlow().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val alertes = dao.alertesFlow().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val stats = combine(sites, ops) { s, o -> s.map { calc(it, o) } }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val message = MutableStateFlow<String?>(null)
    val tick = MutableStateFlow(0)

    fun verifier() { tick.value++; viewModelScope.launch { FuelEngine.run(app) } }

    fun ajouterSite(nom: String, loc: String, stock: Double, conso: Double) = viewModelScope.launch {
        val now = System.currentTimeMillis()
        db.withTransaction {
            val id = dao.insertSite(Site(nom = nom.trim(), localisation = loc.trim(), stockInitial = stock,
                consoJournaliere = conso, creeLe = now, prochainJour = LocalDate.now().toString()))
            dao.insertOp(Operation(siteId = id, type = Type.CHANGEMENT, litres = stock, date = now,
                note = "Stock initial enregistré : ${fmt(stock)} L"))
        }
        message.value = "Site ajouté"
        FuelEngine.run(app)
    }

    fun modifierSite(s: Site, nom: String, loc: String, stock: Double, conso: Double) = viewModelScope.launch {
        val now = System.currentTimeMillis()
        db.withTransaction {
            dao.updateSite(s.copy(nom = nom.trim(), localisation = loc.trim(), stockInitial = stock, consoJournaliere = conso))
            if (stock != s.stockInitial) dao.insertOp(Operation(siteId = s.id, type = Type.CHANGEMENT, litres = stock - s.stockInitial,
                date = now, note = "Stock initial modifié : ${fmt(s.stockInitial)} → ${fmt(stock)} L"))
            if (conso != s.consoJournaliere) dao.insertOp(Operation(siteId = s.id, type = Type.CHANGEMENT, litres = 0.0,
                date = now + 1, note = "Consommation journalière : ${fmt(s.consoJournaliere)} → ${fmt(conso)} L/j"))
        }
        message.value = "Site modifié"
        FuelEngine.run(app)
    }

    fun supprimerSite(s: Site) = viewModelScope.launch { dao.deleteSite(s); message.value = "Site supprimé" }

    fun ravitailler(siteId: Long, litres: Double, note: String) = viewModelScope.launch {
        dao.insertOp(Operation(siteId = siteId, type = Type.RAVITAILLEMENT, litres = litres,
            date = System.currentTimeMillis(), note = note.ifBlank { "Ravitaillement" }))
        message.value = "Ravitaillement enregistré"
        FuelEngine.run(app) // réinitialise le niveau d'alerte si le stock est remonté
    }

    /** Consommation réelle d'un jour : remplace l'estimation de ce jour (jamais de double déduction). */
    fun consoReelle(siteId: Long, litres: Double, jour: LocalDate) = viewModelScope.launch {
        var plafonne = false
        db.withTransaction {
            val s = dao.site(siteId)
            if (s != null) {
                val exist = dao.consoDuJour(siteId, jour.toString())
                val dispo = calc(s, dao.opsOf(siteId)).stock + (exist?.litres ?: 0.0)
                val l = minOf(litres, dispo)
                plafonne = l < litres
                val now = System.currentTimeMillis()
                if (exist != null) dao.updateOp(exist.copy(litres = l, reelle = true, date = now, note = "Consommation réelle"))
                else dao.insertOp(Operation(siteId = siteId, type = Type.CONSOMMATION, litres = l, date = now,
                    jour = jour.toString(), reelle = true, note = "Consommation réelle"))
            }
        }
        message.value = if (plafonne) "Consommation limitée au stock disponible" else "Consommation enregistrée"
        FuelEngine.run(app)
    }

    fun restaurer(uri: android.net.Uri) = viewModelScope.launch {
        message.value = try { Reports.importer(app, uri); FuelEngine.run(app); "Sauvegarde restaurée" }
        catch (e: Exception) { "Fichier de sauvegarde invalide" }
    }
}
