package com.bonytech.fuelalert

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.room.withTransaction
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId

/**
 * Cœur du système : déduit la consommation estimée des journées écoulées (une seule fois par jour et par site),
 * puis déclenche les alarmes lorsqu'un seuil est franchi vers le bas. Idempotent : peut être rappelé à tout moment.
 */
object FuelEngine {
    private val mutex = Mutex()

    suspend fun run(ctx: Context) {
        val events = ArrayList<Alerte>()
        mutex.withLock {
            val db = AppDb.get(ctx)
            val dao = db.dao()
            val today = LocalDate.now()
            db.withTransaction {
                for (s0 in dao.sites()) {
                    var d = LocalDate.parse(s0.prochainJour)
                    while (d.isBefore(today)) {
                        val jour = d.toString()
                        if (dao.consoDuJour(s0.id, jour) == null) { // pas de double déduction
                            val stock = calc(s0, dao.opsOf(s0.id)).stock
                            val l = minOf(s0.consoJournaliere, stock)   // pas de stock négatif
                            if (l > 0) {
                                dao.insertOp(
                                    Operation(
                                        siteId = s0.id, type = Type.CONSOMMATION, litres = l,
                                        date = d.plusDays(1).atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli(),
                                        jour = jour, reelle = false, note = "Consommation estimée"
                                    )
                                )
                            }
                        }
                        d = d.plusDays(1)
                    }
                    val st = calc(s0, dao.opsOf(s0.id), today)
                    var niv = s0.niveauAlerte
                    if (st.niveau > niv) {          // seuil franchi : une seule alerte par niveau
                        events += Alerte(siteId = s0.id, siteNom = s0.nom, niveau = st.niveau, stock = st.stock,
                            joursRestants = st.jours, date = System.currentTimeMillis())
                        niv = st.niveau
                    } else if (st.niveau < niv) {   // stock remonté (ravitaillement) : on réinitialise
                        niv = st.niveau
                    }
                    val s1 = s0.copy(prochainJour = today.toString(), niveauAlerte = niv)
                    if (s1 != s0) dao.updateSite(s1)
                }
                events.forEach { dao.insertAlerte(it) }
            }
        }
        if (events.isNotEmpty()) Notifier.alert(ctx, events)
    }
}

object Scheduler {
    /** Planifie le prochain contrôle (00:01, 06:01, 12:01, 18:01). */
    fun schedule(ctx: Context) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        val now = LocalDateTime.now()
        val next = listOf(0, 6, 12, 18).map { now.toLocalDate().atTime(it, 1) }.firstOrNull { it.isAfter(now) }
            ?: now.toLocalDate().plusDays(1).atTime(0, 1)
        val at = next.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
        val pi = PendingIntent.getBroadcast(
            ctx, 1, Intent(ctx, AlarmReceiver::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        try {
            if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms())
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            else
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        }
    }
}

private fun lancerVerification(c: Context, pr: BroadcastReceiver.PendingResult) {
    val app = c.applicationContext
    CoroutineScope(Dispatchers.Default).launch {
        try { FuelEngine.run(app) } catch (_: Exception) { } finally { pr.finish() }
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) { Scheduler.schedule(c); lancerVerification(c, goAsync()) }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) { Scheduler.schedule(c); lancerVerification(c, goAsync()) }
}
