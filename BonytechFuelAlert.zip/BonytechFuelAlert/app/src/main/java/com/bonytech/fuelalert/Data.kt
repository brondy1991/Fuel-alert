package com.bonytech.fuelalert

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

object Type {
    const val RAVITAILLEMENT = "RAVITAILLEMENT"
    const val CONSOMMATION = "CONSOMMATION"
    const val CHANGEMENT = "CHANGEMENT" // journal uniquement, jamais compté dans le stock
}

@Entity(tableName = "sites")
data class Site(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val nom: String,
    val localisation: String,
    val stockInitial: Double,
    val consoJournaliere: Double,
    val creeLe: Long,
    val prochainJour: String,   // prochain jour dont la consommation estimée n'a pas encore été déduite
    val niveauAlerte: Int = 0   // dernier niveau d'alerte déclenché (0 = aucun)
)

@Entity(
    tableName = "operations",
    foreignKeys = [ForeignKey(entity = Site::class, parentColumns = ["id"], childColumns = ["siteId"], onDelete = ForeignKey.CASCADE)],
    // un seul enregistrement de consommation par site et par jour => aucune double déduction
    indices = [Index("siteId"), Index(value = ["siteId", "jour"], unique = true)]
)
data class Operation(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val siteId: Long,
    val type: String,
    val litres: Double,
    val date: Long,
    val jour: String? = null,   // renseigné uniquement pour CONSOMMATION (yyyy-MM-dd)
    val reelle: Boolean = false,
    val note: String = ""
)

@Entity(tableName = "alertes")
data class Alerte(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val siteId: Long,
    val siteNom: String,
    val niveau: Int,
    val stock: Double,
    val joursRestants: Double?,
    val date: Long
)

@Dao
interface FuelDao {
    @Query("SELECT * FROM sites ORDER BY nom") fun sitesFlow(): Flow<List<Site>>
    @Query("SELECT * FROM sites") suspend fun sites(): List<Site>
    @Query("SELECT * FROM sites WHERE id = :id") suspend fun site(id: Long): Site?
    @Insert suspend fun insertSite(s: Site): Long
    @Update suspend fun updateSite(s: Site)
    @Delete suspend fun deleteSite(s: Site)

    @Query("SELECT * FROM operations ORDER BY date DESC, id DESC") fun opsFlow(): Flow<List<Operation>>
    @Query("SELECT * FROM operations") suspend fun allOps(): List<Operation>
    @Query("SELECT * FROM operations WHERE siteId = :id") suspend fun opsOf(id: Long): List<Operation>
    @Query("SELECT * FROM operations WHERE siteId = :id AND jour = :jour") suspend fun consoDuJour(id: Long, jour: String): Operation?
    @Insert suspend fun insertOp(o: Operation): Long
    @Update suspend fun updateOp(o: Operation)

    @Query("SELECT * FROM alertes ORDER BY date DESC") fun alertesFlow(): Flow<List<Alerte>>
    @Query("SELECT * FROM alertes ORDER BY date DESC") suspend fun alertes(): List<Alerte>
    @Insert suspend fun insertAlerte(a: Alerte)

    @Query("DELETE FROM sites") suspend fun clearSites()
    @Query("DELETE FROM alertes") suspend fun clearAlertes()
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertSites(l: List<Site>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertOps(l: List<Operation>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertAlertes(l: List<Alerte>)
}

@Database(entities = [Site::class, Operation::class, Alerte::class], version = 1, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun dao(): FuelDao

    companion object {
        @Volatile private var inst: AppDb? = null
        fun get(c: Context): AppDb = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(c.applicationContext, AppDb::class.java, "fuel.db").build().also { inst = it }
        }
    }
}
