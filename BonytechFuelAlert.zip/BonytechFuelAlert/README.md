# BONYTECH FUEL ALERT
Ouvrir ce dossier dans Android Studio (Hedgehog ou plus récent), attendre la synchronisation Gradle,
puis Build > Build Bundle(s) / APK(s) > Build APK(s). L'APK : app/build/outputs/apk/debug/app-debug.apk
